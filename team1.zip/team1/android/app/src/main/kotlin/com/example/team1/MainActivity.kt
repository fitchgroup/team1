package com.example.team1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
